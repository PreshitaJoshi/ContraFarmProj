from django.db import models

# Create your models here.


class FirebaseData(models.Model):
     Conductivity=models.CharField(max_length=50,default="abc")
     MainTank=models.CharField(max_length=50,default="abc")
     Phsensor=models.CharField(max_length=50,default="abc")
     Tank1=models.CharField(max_length=50,default="abc")
     Tank2=models.CharField(max_length=50,default="abc")
     Tank3=models.CharField(max_length=50,default="abc")
     Tank4=models.CharField(max_length=50,default="abc")
     Temp=models.CharField(max_length=50,default="abc")
     is_verifed = models.BooleanField(default=False)
     is_active = models.BooleanField(default=True)
     is_updated = models.DateTimeField(auto_now_add=True)
     is_created = models.DateTimeField(auto_now_add=True)





